<?php
   class Redux_Customizer_Control_box_shadow extends Redux_Customizer_Control {
     public $type = "redux-box_shadow";
   }